-----------------------------------------------------------------------------
-- Copyright (C) 2018, 2020 Acoustic, L.P. All rights reserved.  
-- NOTICE: This file contains material that is confidential and proprietary to
-- Acoustic, L.P. and/or other developers. No license is granted under any intellectual or
-- industrial property rights of Acoustic, L.P. except as may be provided in an agreement with
-- Acoustic, L.P. Any unauthorized copying or distribution of content from this file is prohibited.
-----------------------------------------------------------------------------
CREATE TABLE UBX_SentSMS (
	RecordID					bigint IDENTITY(1,1),
	Provider					nvarchar(64) NULL,
	EndpointSource				nvarchar(64) NULL,
	Channel						nvarchar(64) NULL,
	X1ID						nvarchar(64) NULL,
	EventCode					nvarchar(64) NULL,
	EventTimestamp				datetime NOT NULL,
	EventNamespace				nvarchar(64) NULL,
	EventVersion				nvarchar(64) NULL,
	ContactId					nvarchar(64) NULL,
	MobileNumber				nvarchar(64) NULL,
	EventName					nvarchar(256) NULL,
	DeliveryStatus				nvarchar(64) NULL,
	ProgramType					nvarchar(64) NULL,
	LocationCountry				nvarchar(64) NULL,
	Code						nvarchar(64) NULL,
	MessageType					nvarchar(64) NULL,
	MailingTemplateId			nvarchar(256) NULL,
	ExternalSystemReferenceId	nvarchar(256) NULL,
	Source						nvarchar(256) NULL,
	ProgramId					nvarchar(64) NULL,
	CampaignName				nvarchar(256) NULL,
	ProgramName					nvarchar(256) NULL,
	MessageBody					nvarchar(256) NULL,
	EventId						nvarchar(64) NULL,
	CONSTRAINT tUBX_SentSMS_PK PRIMARY KEY (RecordID ASC)
);

CREATE TABLE UBX_InteractedSMS (
	RecordID					bigint IDENTITY(1,1),
	Provider					nvarchar(64) NULL,
	EndpointSource				nvarchar(64) NULL,
	Channel						nvarchar(64) NULL,
	X1ID						nvarchar(64) NULL,
	EventCode					nvarchar(64) NULL,
	EventTimestamp				datetime NOT NULL,
	EventNamespace				nvarchar(64) NULL,
	EventVersion				nvarchar(64) NULL,
	ContactId					nvarchar(64) NULL,
	MobileNumber				nvarchar(64) NULL,
	EventName					nvarchar(256) NULL,
	CampaignName				nvarchar(256) NULL,
	ProgramName					nvarchar(256) NULL,
	ProgramType					nvarchar(64) NULL,
	SetConsent					nvarchar(64) NULL,
	Source						nvarchar(256) NULL,
	EventId						nvarchar(64) NULL,
	CONSTRAINT tUBX_InteractedSMS_PK PRIMARY KEY (RecordID ASC)
);

CREATE TABLE UBX_App_Installed (
	RecordID		bigint IDENTITY(1,1),
	Provider		nvarchar(64) NULL,
	EndpointSource	nvarchar(64) NULL,
	Channel			nvarchar(64) NULL,
	X1ID			nvarchar(64) NULL,
	EventCode		nvarchar(64) NULL,
	EventTimestamp	datetime NOT NULL,
	EventNamespace	nvarchar(64) NULL,
	EventVersion	nvarchar(64) NULL,
	UserId			nvarchar(64) NULL,
	AppKey			nvarchar(64) NULL,
	ChannelId		nvarchar(64) NULL,
	Url				nvarchar(64) NULL,
	Attribution		nvarchar(64) NULL,
	CONSTRAINT tUBX_App_Installed_PK PRIMARY KEY (RecordID ASC)
);

CREATE TABLE UBX_App_Uninstalled (
	RecordID		bigint IDENTITY(1,1),
	Provider		nvarchar(64) NULL,
	EndpointSource	nvarchar(64) NULL,
	Channel			nvarchar(64) NULL,
	X1ID			nvarchar(64) NULL,
	EventCode		nvarchar(64) NULL,
	EventTimestamp	datetime NOT NULL,
	EventNamespace	nvarchar(64) NULL,
	EventVersion	nvarchar(64) NULL,
	UserId			nvarchar(64) NULL,
	AppKey			nvarchar(64) NULL,
	ChannelId		nvarchar(64) NULL,
	Url				nvarchar(64) NULL,
	Attribution		nvarchar(64) NULL,
	CONSTRAINT tUBX_App_Uninstalled_PK PRIMARY KEY (RecordID ASC)
);

CREATE TABLE UBX_App_SessionStarted (
	RecordID		bigint IDENTITY(1,1),
	Provider		nvarchar(64) NULL,
	EndpointSource	nvarchar(64) NULL,
	Channel			nvarchar(64) NULL,
	X1ID			nvarchar(64) NULL,
	EventCode		nvarchar(64) NULL,
	EventTimestamp	datetime NOT NULL,
	EventNamespace	nvarchar(64) NULL,
	EventVersion	nvarchar(64) NULL,
	UserId			nvarchar(64) NULL,
	AppKey			nvarchar(64) NULL,
	ChannelId		nvarchar(64) NULL,
	Url				nvarchar(64) NULL,
	Attribution		nvarchar(64) NULL,
	CONSTRAINT tUBX_App_SessionStarted_PK PRIMARY KEY (RecordID ASC)
);

CREATE TABLE UBX_App_SessionEnded (
	RecordID		bigint IDENTITY(1,1),
	Provider		nvarchar(64) NULL,
	EndpointSource	nvarchar(64) NULL,
	Channel			nvarchar(64) NULL,
	X1ID			nvarchar(64) NULL,
	EventCode		nvarchar(64) NULL,
	EventTimestamp	datetime NOT NULL,
	EventNamespace	nvarchar(64) NULL,
	EventVersion	nvarchar(64) NULL,
	UserId			nvarchar(64) NULL,
	AppKey			nvarchar(64) NULL,
	ChannelId		nvarchar(64) NULL,
	Url				nvarchar(64) NULL,
	Attribution		nvarchar(64) NULL,
	CONSTRAINT tUBX_App_SessionEnded_PK PRIMARY KEY (RecordID ASC)
);

CREATE TABLE UBX_App_UIPushEnabled (
	RecordID		bigint IDENTITY(1,1),
	Provider		nvarchar(64) NULL,
	EndpointSource	nvarchar(64) NULL,
	Channel			nvarchar(64) NULL,
	X1ID			nvarchar(64) NULL,
	EventCode		nvarchar(64) NULL,
	EventTimestamp	datetime NOT NULL,
	EventNamespace	nvarchar(64) NULL,
	EventVersion	nvarchar(64) NULL,
	UserId			nvarchar(64) NULL,
	AppKey			nvarchar(64) NULL,
	ChannelId		nvarchar(64) NULL,
	Url				nvarchar(64) NULL,
	Attribution		nvarchar(64) NULL,
	CONSTRAINT tUBX_App_UIPushEnabled_PK PRIMARY KEY (RecordID ASC)
);

CREATE TABLE UBX_App_UIPushDisabled (
	RecordID		bigint IDENTITY(1,1),
	Provider		nvarchar(64) NULL,
	EndpointSource	nvarchar(64) NULL,
	Channel			nvarchar(64) NULL,
	X1ID			nvarchar(64) NULL,
	EventCode		nvarchar(64) NULL,
	EventTimestamp	datetime NOT NULL,
	EventNamespace	nvarchar(64) NULL,
	EventVersion	nvarchar(64) NULL,
	UserId			nvarchar(64) NULL,
	AppKey			nvarchar(64) NULL,
	ChannelId		nvarchar(64) NULL,
	Url				nvarchar(64) NULL,
	Attribution		nvarchar(64) NULL,
	CONSTRAINT tUBX_App_UIPushDisabled_PK PRIMARY KEY (RecordID ASC)
);

CREATE TABLE UBX_SimpNot_appOpened (
	RecordID		bigint IDENTITY(1,1),
	Provider		nvarchar(64) NULL,
	EndpointSource	nvarchar(64) NULL,
	Channel			nvarchar(64) NULL,
	X1ID			nvarchar(64) NULL,
	EventCode		nvarchar(64) NULL,
	EventTimestamp	datetime NOT NULL,
	EventNamespace	nvarchar(64) NULL,
	EventVersion	nvarchar(64) NULL,
	UserId			nvarchar(64) NULL,
	AppKey			nvarchar(64) NULL,
	ChannelId		nvarchar(64) NULL,
	Url				nvarchar(64) NULL,
	Attribution		nvarchar(64) NULL,
	CONSTRAINT tUBX_SimpNot_appOpened_PK PRIMARY KEY (RecordID ASC)
);

CREATE TABLE UBX_SimpNot_URLClicked (
	RecordID		bigint IDENTITY(1,1),
	Provider		nvarchar(64) NULL,
	EndpointSource	nvarchar(64) NULL,
	Channel			nvarchar(64) NULL,
	X1ID			nvarchar(64) NULL,
	EventCode		nvarchar(64) NULL,
	EventTimestamp	datetime NOT NULL,
	EventNamespace	nvarchar(64) NULL,
	EventVersion	nvarchar(64) NULL,
	UserId			nvarchar(64) NULL,
	AppKey			nvarchar(64) NULL,
	ChannelId		nvarchar(64) NULL,
	Url				nvarchar(64) NULL,
	Attribution		nvarchar(64) NULL,
	CONSTRAINT tUBX_SimpNot_URLClicked_PK PRIMARY KEY (RecordID ASC)
);

CREATE TABLE UBX_WFX_EVENTS (
	RecordID		bigint IDENTITY(1,1),
	Provider		nvarchar(64) NULL,
	EndpointSource	nvarchar(64) NULL,
	Channel			nvarchar(64) NULL,
	X1ID			nvarchar(64) NULL,
	EventCode		nvarchar(64) NULL,
	EventTimestamp	datetime NOT NULL,
	EventNamespace	nvarchar(64) NULL,
	EventVersion	nvarchar(64) NULL,
	PostalCode		nvarchar(64) NULL,
	CountryCode		nvarchar(64) NULL,
	CurrentDay		float NULL,
	ForecastDay0	float NULL,
	ForecastDay1	float NULL,
	ForecastDay2	float NULL,
	ForecastDay3	float NULL,
	ForecastDay4	float NULL,
	ForecastDay5	float NULL,
	ForecastDay6	float NULL,
	ForecastDay7	float NULL,
	ForecastDay8	float NULL,
	CONSTRAINT tUBX_WFX_EVENTS_PK PRIMARY KEY (RecordID ASC)
);

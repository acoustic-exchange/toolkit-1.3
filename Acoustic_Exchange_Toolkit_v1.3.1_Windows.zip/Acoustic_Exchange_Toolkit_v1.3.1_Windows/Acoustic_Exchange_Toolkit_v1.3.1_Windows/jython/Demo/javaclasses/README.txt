Object factories should be implemented in order to use Jython classes from Java applications.  To learn more about object factories, please visit the Jython book and the PlyJy project.

Jython Book:  http://www.jythonbook.com

PlyJy:  http://kenai.com/projects/plyjy

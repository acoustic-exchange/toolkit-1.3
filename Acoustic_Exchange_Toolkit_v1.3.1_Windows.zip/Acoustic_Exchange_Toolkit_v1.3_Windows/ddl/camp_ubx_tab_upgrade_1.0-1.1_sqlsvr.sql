-----------------------------------------------------------------------------
-- Copyright (C) 2018, 2020 Acoustic, L.P. All rights reserved.  
-- NOTICE: This file contains material that is confidential and proprietary to
-- Acoustic, L.P. and/or other developers. No license is granted under any intellectual or
-- industrial property rights of Acoustic, L.P. except as may be provided in an agreement with
-- Acoustic, L.P. Any unauthorized copying or distribution of content from this file is prohibited.
-----------------------------------------------------------------------------
CREATE TABLE UBX_EmailSend (
	RecordID		bigint IDENTITY(1,1),
	Provider		nvarchar(64) NULL,
	EndpointSource	nvarchar(64) NULL,
	Channel			nvarchar(64) NULL,
	X1ID			nvarchar(64) NULL,
	ContactId		nvarchar(64) NULL,
	Email			nvarchar(64) NULL,
	EventCode		nvarchar(64) NOT NULL,
	EventTimeStamp	datetime NOT NULL,
	EventNameSpace	nvarchar(64) NULL,
	EventVersion	nvarchar(64) NULL,			
	EventName		nvarchar(64) NULL,
	Description		nvarchar(128) NULL,
	MessageId		bigint NULL,
	MailingTemplateId bigint NULL,
	ReportId		nvarchar(64) NULL,	
	SubjectLine 	nvarchar(256) NULL,
	MessageName 	nvarchar(256) NULL,
	DocType	    	nvarchar(64) NULL,
	SendType    	nvarchar(64) NULL,
	EventId     	nvarchar(64) NULL,
    CONSTRAINT tUBX_EmailSend_PK PRIMARY KEY (RecordID ASC)
);

CREATE TABLE UBX_EmailOpen (
	RecordID		bigint IDENTITY(1,1),
	Provider		nvarchar(64) NULL,
	EndpointSource	nvarchar(64) NULL,
	Channel			nvarchar(64) NULL,
	X1ID			nvarchar(64) NULL,
	ContactId		nvarchar(64) NULL,
	Email			nvarchar(64) NULL,
	EventCode		nvarchar(64) NOT NULL,
	EventTimeStamp	datetime NOT NULL,
	EventNameSpace	nvarchar(64) NULL,
	EventVersion	nvarchar(64) NULL,				
	EventName		nvarchar(64) NULL,
	Description		nvarchar(128) NULL,
	MessageId		bigint NULL,
	MailingTemplateId bigint NULL,
	ReportId		nvarchar(64) NULL,	
	SubjectLine 	nvarchar(256) NULL,
	MessageName 	nvarchar(256) NULL,
	DocType	    	nvarchar(64) NULL,
	EventId     	nvarchar(64) NULL,
    CONSTRAINT tUBX_EmailOpen_PK PRIMARY KEY (RecordID ASC)
);

CREATE TABLE UBX_EmailClick (
	RecordID		bigint IDENTITY(1,1),
	Provider		nvarchar(64) NULL,
	EndpointSource	nvarchar(64) NULL,
	Channel			nvarchar(64) NULL,
	X1ID			nvarchar(64) NULL,
	ContactId		nvarchar(64) NULL,
	Email			nvarchar(64) NULL,
	EventCode		nvarchar(64) NOT NULL,
	EventTimeStamp	datetime NOT NULL,
	EventNameSpace	nvarchar(64) NULL,
	EventVersion	nvarchar(64) NULL,				
	EventName		nvarchar(64) NULL,
	Description		nvarchar(128) NULL,
	MessageId		bigint NULL,
	MailingTemplateId bigint NULL,
	ReportId		nvarchar(64) NULL,	
	SubjectLine 	nvarchar(256) NULL,
	MessageName 	nvarchar(256) NULL,
	DocType	    	nvarchar(64) NULL,
	ClickUrl    	nvarchar(128) NULL,
	UrlDescription  nvarchar(128) NULL,
	EventId     	nvarchar(64) NULL,
    CONSTRAINT tUBX_EmailClick_PK PRIMARY KEY (RecordID ASC)
);

CREATE TABLE UBX_EmailBounce (
	RecordID		bigint IDENTITY(1,1),
	Provider		nvarchar(64) NULL,
	EndpointSource	nvarchar(64) NULL,
	Channel			nvarchar(64) NULL,
	X1ID			nvarchar(64) NULL,
	ContactId		nvarchar(64) NULL,
	Email			nvarchar(64) NULL,
	EventCode		nvarchar(64) NOT NULL,
	EventTimeStamp	datetime NOT NULL,
	EventNameSpace	nvarchar(64) NULL,
	EventVersion	nvarchar(64) NULL,							
	EventName		nvarchar(64) NULL,	
	Description		nvarchar(128) NULL,
	MessageId		bigint NULL,
	MailingTemplateId bigint NULL,
	ReportId		nvarchar(64) NULL,	
	SubjectLine 	nvarchar(256) NULL,
	MessageName 	nvarchar(256) NULL,
	DocType	    	nvarchar(64) NULL,
	BounceType    	nvarchar(64) NULL,
	EventId     	nvarchar(64) NULL,
    CONSTRAINT tUBX_EmailBounce_PK PRIMARY KEY (RecordID ASC)
);

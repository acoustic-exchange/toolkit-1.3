This example demonstrates a simple Jython console.  Please run by executing the following statement:

jython Console.py
